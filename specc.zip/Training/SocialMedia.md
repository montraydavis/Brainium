# Prompt

```markdown
Generate YAML Configuration:

- Social Media Platform
  - Profile Page
    - Posts Grid
      - Post Thumbnail
      - Post Caption
    - Followers Count
    - Following Count
  - Post Page
    - Post Content
    - Like Button
    - Comment Section
      - Individual Comments
        - Commenter Name
        - Comment Content

```

# Response

```yaml
socialMediaPlatform: &socialMediaPlatform
  name: socialMediaPlatform
  description: "Social Media Platform"
  locator: "body"
  components: &socialMediaPlatformComponents
    profilePage: &profilePage
      name: profilePage
      description: "Profile Page"
      locator: "div.profile-page"
      children:
        - postsGrid: &postsGrid
          name: postsGrid
          description: "Grid of posts"
          locator: "div.posts-grid"
          row:
            - postsGridGridItem: &postsGridGridItem
              name: postsGridGridItem
              description: "Individual post in the grid"
              locator: "div.post-item"
              children:
                - postsGridPostThumbnail: &postsGridPostThumbnail
                  name: postsGridPostThumbnail
                  description: "Thumbnail of the post"
                  locator: "img.post-thumbnail"
                - postsGridPostCaptionText: &postsGridPostCaptionText
                  name: postsGridPostCaptionText
                  description: "Caption of the post"
                  locator: "span.post-caption"
        - profilePageFollowersCountLabel: &profilePageFollowersCountLabel
          name: profilePageFollowersCountLabel
          description: "Count of followers"
          locator: "span.followers-count"
        - profilePageFollowingCountLabel: &profilePageFollowingCountLabel
          name: profilePageFollowingCountLabel
          description: "Count of following"
          locator: "span.following-count"
    postPage: &postPage
      name: postPage
      description: "Post Page"
      locator: "div.post-page"
      children:
        - postPagePostContentText: &postPagePostContentText
          name: postPagePostContentText
          description: "Content of the post"
          locator: "div.post-content"
        - postPageLikeButton: &postPageLikeButton
          name: postPageLikeButton
          description: "Button to like the post"
          locator: "button.like-button"
        - commentSection: &commentSection
          name: commentSection
          description: "Section for comments on the post"
          locator: "div.comment-section"
          row:
            - commentSectionGridItem: &commentSectionGridItem
              name: commentSectionGridItem
              description: "Individual comment on the post"
              locator: "div.comment-item"
              children:
                - commentCommenterNameLabel: &commentCommenterNameLabel
                  name: commentCommenterNameLabel
                  description: "Name of the commenter"
                  locator: "span.commenter-name"
                - commentContentText: &commentContentText
                  name: commentContentText
                  description: "Content of the comment"
                  locator: "p.comment-content"
```
# Prompt

```markdown
Generate YAML Configuration:

- E-commerce Website
  - Homepage
    - Featured Products Carousel
      - Product Image
      - Buy Now Button
  - Product Page
    - Product Images Gallery
    - Product Description
    - Add to Cart Button
    - Reviews Section
      - Individual Reviews
        - Reviewer Name
        - Review Content
```

# Response

```yaml
ecommerceWebsite: &ecommerceWebsite
  name: ecommerceWebsite
  description: "E-commerce Website"
  locator: "body"
  components: &ecommerceWebsiteComponents
    homepage: &homepage
      name: homepage
      description: "Homepage"
      locator: "div.homepage"
      children:
        - featuredProductsCarousel: &featuredProductsCarousel
          name: featuredProductsCarousel
          description: "Carousel for featured products"
          locator: "div.featured-carousel"
          children:
            - featuredProductsProductImage: &featuredProductsProductImage
              name: featuredProductsProductImage
              description: "Image of the product"
              locator: "img.product-img"
            - featuredProductsBuyNowButton: &featuredProductsBuyNowButton
              name: featuredProductsBuyNowButton
              description: "Button to buy the product immediately"
              locator: "button.buy-now"
    productPage: &productPage
      name: productPage
      description: "Product Page"
      locator: "div.product-page"
      children:
        - productImagesGallery: &productImagesGallery
          name: productImagesGallery
          description: "Gallery of product images"
          locator: "div.images-gallery"
        - productDescriptionText: &productDescriptionText
          name: productDescriptionText
          description: "Description of the product"
          locator: "p.product-description"
        - addToCartButton: &addToCartButton
          name: addToCartButton
          description: "Button to add the product to the cart"
          locator: "button.add-to-cart"
        - reviewsSection: &reviewsSection
          name: reviewsSection
          description: "Section containing product reviews"
          locator: "section.reviews"
          row:
            - reviewsSectionGridItem: &reviewsSectionGridItem
              name: reviewsSectionGridItem
              description: "Individual review"
              locator: "div.review"
              children:
                - reviewReviewerNameLabel: &reviewReviewerNameLabel
                  name: reviewReviewerNameLabel
                  description: "Name of the reviewer"
                  locator: "span.reviewer-name"
                - reviewContentText: &reviewContentText
                  name: reviewContentText
                  description: "Content of the review"
                  locator: "p.review-content"

```
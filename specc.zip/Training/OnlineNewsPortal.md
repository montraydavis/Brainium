# Prompt

```markdown
Generate YAML Configuration:

- News Portal
  - Homepage
    - Top Stories Carousel
      - Story Headline
      - Read More Button
    - Latest News Section
      - News Item
        - News Headline
        - News Summary
  - Article Page
    - Article Content
    - Share Buttons
    - Comment Section
      - Individual Comments
        - Commenter Name
        - Comment Content
```

# Response

```yaml
newsPortal: &newsPortal
  name: newsPortal
  description: "Online News Portal"
  locator: "body"
  components: &newsPortalComponents
    homepage: &homepage
      name: homepage
      description: "Homepage of the news portal"
      locator: "div.homepage"
      children:
        - topStoriesCarousel: &topStoriesCarousel
          name: topStoriesCarousel
          description: "Carousel of top stories"
          locator: "div.top-stories"
          children:
            - topStoriesStoryHeadlineLabel: &topStoriesStoryHeadlineLabel
              name: topStoriesStoryHeadlineLabel
              description: "Headline of the story"
              locator: "h1.story-headline"
            - topStoriesReadMoreButton: &topStoriesReadMoreButton
              name: topStoriesReadMoreButton
              description: "Button to read more about the story"
              locator: "button.read-more"
        - latestNewsSection: &latestNewsSection
          name: latestNewsSection
          description: "Section for the latest news"
          locator: "section.latest-news"
          row:
            - latestNewsSectionGridItem: &latestNewsSectionGridItem
              name: latestNewsSectionGridItem
              description: "Individual news item"
              locator: "div.news-item"
              children:
                - latestNewsNewsHeadlineLabel: &latestNewsNewsHeadlineLabel
                  name: latestNewsNewsHeadlineLabel
                  description: "Headline of the news item"
                  locator: "h2.news-headline"
                - latestNewsNewsSummaryText: &latestNewsNewsSummaryText
                  name: latestNewsNewsSummaryText
                  description: "Summary of the news item"
                  locator: "p.news-summary"
    articlePage: &articlePage
      name: articlePage
      description: "Article Page"
      locator: "div.article-page"
      children:
        - articleContentText: &articleContentText
          name: articleContentText
          description: "Content of the article"
          locator: "div.article-content"
        - shareButtons: &shareButtons
          name: shareButtons
          description: "Social share buttons"
          locator: "div.share-buttons"
        - commentSection: &commentSection
          name: commentSection
          description: "Section for article comments"
          locator: "div.comment-section"
          row:
            - commentSectionGridItem: &commentSectionGridItem
              name: commentSectionGridItem
              description: "Individual comment on the article"
              locator: "div.comment-item"
              children:
                - commentCommenterNameLabel: &commentCommenterNameLabel
                  name: commentCommenterNameLabel
                  description: "Name of the commenter"
                  locator: "span.commenter-name"
                - commentContentText: &commentContentText
                  name: commentContentText
                  description: "Content of the comment"
                  locator: "p.comment-content"
```
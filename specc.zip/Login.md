# Test Plan

## Introduction

This document outlines the test plan for [Project Name]. The purpose of this test plan is to ensure the functionality and reliability of the [Project Name] software/application/system.

## Scope

This test plan covers the testing of all functionalities and features of the [Project Name]. It includes but is not limited to:

- User interface testing
- Functional testing
- Performance testing
- Compatibility testing
- Security testing

## Test Strategy

The testing will be conducted in various stages including:

1. Unit testing
2. Integration testing
3. System testing
4. Acceptance testing

## Test Environment

The testing will be conducted in the following environment:

- Operating System: Windows
- Browser: Google Chrome / Microsoft Edge / Mozilla Firefox
- Devices: Laptop

## Test Cases

### Page: Login Page

#### Success Login

    1. Enter a valid username.
    2. Enter a valid password.
    3. Click the login button.

> Expected Result: The user should be logged in successfully and redirected to the dashboard/homepage.

#### Unsuccessful Login

    1. Enter an invalid username.
    2. Enter an invalid password.
    3. Click the login button.

> Expected Result: The user should not be logged in. An error message should be displayed indicating invalid login credentials.

## Forgot Password

    1. Click the `Forgot Password` link.
    2. Enter your username.
    3. Click the `Continue` button.
    4. Click the `Send Verification Code` button.
    5. Enter the Verification Code received.
    6. Click the `Verify Code` button.
    7. Enter your new password.
    8. Enter the confirmation of the new password.
    9. Click the `Continue` button.

> Expected Result: The user should be able to reset their password successfully. A confirmation message should be displayed indicating successful password reset.

## Client Select Page

### Search Clients

    1. Enter the client name in the search field.

> Expected Result: The system should display only the clients that match the entered name.

### Select Client

    1. Click on the row of the desired client.

> Expected Result: The system should log in as the selected client. The system should redirect user to the `Dashboard` page.

## Dashboard Page

### Validate Components Loading

    1. Check if the Position Pipeline component is loading correctly.
    2. Check if the Market Movement component is loading correctly.
    3. Check if the Loans Available for Sale component is loading correctly.
    4. Check if the Latest Bid Request component is loading correctly.
    5. Check if the Shock Profile component is loading correctly.
       - GL Tab
       - Position Tab
       - Data Tab
    6. Check if the Month-To-Date Snapshot component is loading correctly.
       - GL Tab
       - Locks/Coverage Tab
       - Base Instrument Tab
       - Position Tab
    7. Check if the Locks component is loading correctly.
       - Filter By Products
    8. Check if the Loan Sales Summary component is loading correctly.
    9. Check if the Loan Sales (Rolling 30 Days) component is loading correctly.
    10. Check if the Recent Trades component is loading correctly.
    11. Check if the Lock Volume component is loading correctly.

> Expected Result: All the components should load correctly without any errors.

### Position Pipeline Link

    1. Click on the Position Pipeline link.

> Expected Result: The user should be redirected to the `hedgeposition` page.

### Test Case: Loans Available For Sale Link

> Expected Result: The user should be redirected to the `request-bids` page.

### Test Case: Latest Bid Request Link

    1. Click on the Latest Bid Request link.

> Expected Result: The user should be redirected to the `commit-loans` page.

### Test Case: Recent Trades Link

    1. Click on the Recent Trades link.

> Expected Result: The user should be redirected to the `trademanagement` page.

## Position Recon Page

### Test Case: Validate Components Load

    1. Check if the Recon Grid loads correctly.
    2. Check if the Grid Columns load correctly.
       - Attribute Categories
       - Unclosed Position
       - Closed Position
       - Hedge Position
       - Net Position Change
    3. Check if the Grid Date Range Filter works correctly.
       - The user should be able to validate the date range from `comparing from` to `comparing to`.

> Expected Result: All the components should load correctly and the date range filter should work as expected.

### Test Case: Definitions Link

    1. Click on the Definitions link.

> Expected Result: A modal window should appear displaying the `Position Attribute Definitions`.

- **Test Case: Position Attribute Definitions Modal Filter**
  1. Enter a search term in the filter input of the `Position Attribute Definitions` modal.

> Expected Result: The definitions displayed should be filtered based on the entered search term.

## Daily Gain/Loss Attribution Page

### Test Case: Validate Components Load

    1. Check if the Summary Tab loads data correctly.
       - Summary Bar Chart
    2. Check if the Details Tab loads data correctly.
       - Details Grid
    3. Check if the Grid Date Range Filter works correctly.
       - The user should be able to limit the data range using the `comparing from` to `comparing to` dropdowns.

> Expected Result: All the components should load correctly and the date range filter should work as expected.

### Test Case: Definitions Link

    1. Click on the Definitions link.

> Expected Result: A modal window should appear displaying the `Position Attribute Definitions`.



## Conclusion

This test plan aims to ensure thorough testing of all functionalities of [Project Name]. It will be continuously updated as testing progresses to accommodate any changes or new features.

# Loan Detail Viewer Page Components

This document details the components within the Loan Detail Viewer page, focusing on the functionalities designed for in-depth analysis and modification of loan-related data.

## Transformed Values Tab
- **Identifier:** `transformedValuesTab`
- **Description:** This tab displays a grid of transformed loan values, providing users with processed and standardized loan information. The transformation aims to facilitate comparisons and analyses by normalizing raw loan data into a consistent format.

## Raw Loans Values Tab
- **Identifier:** `rawLoansValuesTab`
- **Description:** Offers a detailed view of the raw loan data without any transformations. This tab is crucial for users needing to access the unaltered data for comprehensive analysis or verification purposes.

### Transformed Values Grid
- **Identifier:** `transformedValuesGrid`
- **Description:** Located within the Transformed Values Tab, this grid presents the processed data for each loan. It is an essential tool for users analyzing the standardized metrics of loan performance.

#### Loan Number Link
- **Identifier:** `loanNumberLink`
- **Description:** A navigational component within the Transformed Values Grid that enables users to open the Loan Detail Viewer page for a detailed analysis of the selected loan number. This link provides a seamless transition to further in-depth loan information.

### Raw Loans Values Grid
- **Identifier:** `rawLoansValuesGrid`
- **Description:** This grid, situated in the Raw Loans Values Tab, displays the raw, unprocessed loan data. It serves as a fundamental resource for users looking to analyze or cross-reference the original loan data.

#### Update Loan Data Button
- **Identifier:** `updateLoanDataButton`
- **Description:** A functional component within the Raw Loans Values Grid, this button allows users to initiate updates to the loan data. It is key for maintaining the accuracy and timeliness of loan information in the system.

This detailed documentation is aimed at providing users and developers with a comprehensive understanding of the Loan Detail Viewer page's components, highlighting their roles in facilitating the detailed examination and management of loan data.

# Test Cases for Loan Detail Viewer Page

Detailed test cases designed to validate the functionality and reliability of the components on the Loan Detail Viewer page.

## Test Case: Validate Components

### Objective
To ensure all key components within the Loan Detail Viewer page are loading correctly and are operational.

### Description
This test case focuses on validating the proper loading and functionality of the Transformed Values Tab with its grid, and the Raw Loans Values Tab with its grid.

### Steps
1. **Validate Tab Navigation:** Confirm that switching between the `Transformed Values` and `Raw Loans Values` tabs is seamless and functional.
2. **Validate Transformed Values Grid:** Ensure the `Transformed Values` tab accurately loads the Transformed Values Grid.
3. **Validate Raw Loans Values Grid:** Check that the `Raw Loans Values` tab correctly displays the Raw Loans Values Grid.

### Expected Results
- All components are loaded successfully and are fully operational, enabling users to navigate and interact with the loan data effectively.

## Test Case: Validate `Transformed Values Grid > Loan Number Link` Opens Loan Details Viewer

### Objective
To verify that clicking the Loan Number Link within the Transformed Values Grid opens the Loan Detail Viewer page for the selected loan.

### Description
This test case aims to ensure the Loan Number Link's functionality is intact, providing a direct link to more detailed loan information.

### Steps
1. Navigate to the `Transformed Values` tab in the Loan Detail Viewer page.
2. **Click on the Loan Number Link:** Select any loan number link within the Transformed Values Grid.
3. **Validate Loan Detail Viewer Page:** Confirm that the Loan Detail Viewer page opens, showcasing detailed information about the chosen loan.

### Expected Results
- Selecting the Loan Number Link from the Transformed Values Grid correctly navigates to the Loan Detail Viewer page, where detailed loan information is accurately displayed, aiding in the thorough examination of loan details.

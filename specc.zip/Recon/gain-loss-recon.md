# Gain/Loss Recon Page Components

This document provides detailed descriptions of the components on the Gain/Loss Recon page, focusing on functionality designed to facilitate the comparison and analysis of financial gain/loss over selected periods.

## Comparing From Input
- **Identifier:** `comparingFromInput`
- **Description:** A dropdown component that allows users to select the start date for the comparison period. This input is crucial for defining the temporal scope of the gain/loss analysis, enabling users to focus on specific intervals for detailed financial examination.

## Comparing To Input
- **Identifier:** `comparingToInput`
- **Description:** Similar to the Comparing From Input, this dropdown enables users to select the end date for the comparison period. It complements the Comparing From Input by finalizing the timeframe over which the gain/loss analysis is conducted, ensuring a precise period for financial review.

## Summary Tab
The Summary Tab aggregates and displays a high-level overview of gain/loss data, providing users with quick insights into financial performance over the selected period.

### Summary Grid
- **Identifier:** `summaryGrid`
- **Description:** This component is a bar chart that visualizes the summary of Daily Gain/Loss data. It offers a graphical representation of financial performance, making it easier for users to identify trends, patterns, and anomalies in gain/loss over the selected timeframe. The use of a bar chart aids in the rapid assessment of financial health and assists in pinpointing areas that may require further investigation.

## Details Grid
The Details Grid dives deeper into the specifics of gain/loss data, breaking down the financials into categories for a granular analysis.

### Details Grid
- **Identifier:** `detailsGrid`
- **Description:** Displays detailed information categorized by `Category`, `Notional`, and `Secondary Gain/Loss`. This grid is essential for users who need to dissect the financial data further, offering insights into specific categories of gain or loss. It allows for a thorough examination of notional values and secondary gain/loss metrics, facilitating a comprehensive understanding of financial performance across different segments.

- **Components:**
  - **Category:** Represents the financial category under review, providing a classification of gain/loss data for organizational clarity.
  - **Notional:** Displays the notional amount associated with each category, offering insights into the scale of transactions and their impact on financial performance.
  - **Secondary Gain/Loss:** Provides data on secondary financial outcomes, giving users a more detailed perspective on the intricacies of financial performance beyond primary gain/loss metrics.

This in-depth documentation outlines the core components of the Gain/Loss Recon page, detailing their roles and contributions to the analysis of financial performance over selected periods. By offering tools for both high-level overview and detailed breakdown, this page facilitates a comprehensive financial examination, aiding users in making informed decisions based on gain/loss metrics.

# Test Cases for Gain/Loss Recon Page

This document provides detailed test cases designed to validate the functionality and reliability of components on the Gain/Loss Recon page.

## Test Case: Validate Components

### Objective
To ensure all primary components within the Gain/Loss Recon page are loading correctly and are operational.

### Description
This test case aims to validate the correct loading of the Comparing From dropdown, Comparing To dropdown, Summary tab with its Summary grid, and the Details tab with its Details grid.

### Steps
1. Validate the `Comparing From` dropdown loads successfully on the page.
2. Validate the `Comparing To` dropdown loads successfully on the page.
3. Navigate to the `Summary` tab and validate that the Summary grid is present and loaded.
4. Navigate to the `Details` tab and validate that the Details grid is present and loaded.

### Expected Results
- All specified components (Comparing From dropdown, Comparing To dropdown, Summary tab with Summary grid, and Details tab with Details grid) are loaded successfully and are fully operational.

## Test Case: Validate Date Range Selection

### Objective
To verify that the date range selection functionality works as expected and that the corresponding data in both the Summary bar chart and the Gain/Loss Recon grid reflects the selected date range accurately.

### Description
This test case focuses on the date range selection feature, ensuring that users can select dates and that the data displayed within the Gain/Loss Recon page accurately corresponds to the selected dates.

### Steps
1. Select a specific date in the `Comparing From` dropdown.
2. Select a specific date in the `Comparing To` dropdown, ensuring it is after the Comparing From date.
3. Observe the Summary bar chart within the Summary tab for any updates or changes to reflect the selected date range.
4. Navigate to the Details tab and observe the Gain/Loss Recon grid for any updates or changes to reflect the selected date range.

### Expected Results
- The `Summary` bar chart updates to reflect the data within the selected date range, accurately displaying daily gain/loss information.
- The `Gain/Loss Recon` grid within the Details tab updates to display detailed gain/loss information, categorized appropriately for the selected date range.

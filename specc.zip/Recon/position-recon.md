# Position Recon Page Components

This document elaborates on the components within the Position Recon page, highlighting functionalities designed for analyzing financial positions over selected time frames.

## Components

### Comparing From Input
- **Identifier:** `comparingFromInput`
- **Description:** A Date Picker component allowing users to select the start date from which the comparison of positions will begin. This tool is vital for setting the initial point of the time range for financial analysis.

### Comparing To Input
- **Identifier:** `comparingToInput`
- **Description:** A Date Picker component that enables users to select the end date to which the position data will be compared. It establishes the closing boundary of the analysis period, allowing for targeted financial scrutiny within specific time frames.

### Position Recon Grid
- **Identifier:** `positionReconGrid`
- **Description:** This grid displays the Position Recon data, showcasing detailed information about financial positions over the chosen date range. It is instrumental in providing users with a comprehensive view of position fluctuations and trends within the specified period.

# Test Cases for Position Recon Page

## Test Case: Validate Components

### Objective
To ensure all primary components on the Position Recon page are correctly loaded and functional.

### Description
This test case is designed to verify the proper loading and functionality of the Comparing From Input, Comparing To Input, and the Position Recon Grid components on the Position Recon page.

### Steps
1. **Navigate to the `Position Recon` page.** Ensure access to the page where the components are located.

### Expected Results
- **Validate `Comparing From Input` component loaded successfully:** Confirm that the date picker for selecting the starting comparison date is operational.
- **Validate `Comparing To Input` component loaded successfully:** Ensure the date picker for selecting the ending comparison date is fully functional.
- **Validate `Position Recon Grid` component loaded successfully:** Verify that the grid displaying Position Recon data is correctly loaded and displays data according to the selected date range.

## Test Case: Validate date range `Comparing From Input` selection

### Objective
To confirm that the Position Recon Grid reflects the data corresponding to the date range selected via the Comparing From Input.

### Description
This test focuses on the Comparing From Input's functionality, verifying that adjusting the start date influences the Position Recon Grid's data display as expected.

### Steps
1. **Change date range in the `Comparing From` date.** Select a new start date to adjust the data range.

### Expected Results
- **Validate the `Position Recon` grid loads with the selected date range:** The Position Recon Grid should update to reflect the data for the new date range set by the Comparing From Input.

## Test Case: Validate date range `Comparing To Input` selection

### Objective
To ensure that the Position Recon Grid accurately updates based on the date range selected via the Comparing To Input.

### Description
This test validates the Comparing To Input's effectiveness in altering the Position Recon Grid's data display according to the chosen end date.

### Steps
1. **Change date range in the `Comparing To` date.** Adjust the end date to redefine the analysis period.

### Expected Results
- **Validate the `Position Recon` grid loads with the selected date range:** After adjusting the end date through the Comparing To Input, the Position Recon Grid should correctly display data that aligns with the new date range.

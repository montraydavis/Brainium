Help me generate a markdown formatted test-plan in which by page, lists all functionalities a user can take.

Generate a template.

----

Add forgot password:

- Click `Forgot Password` link.
- Enter username.
- Click `Continue` button.
- Click `Send Verification Code` button.
- Enter Verification Code
- Click `Verify Code` button
- Enter New Password
- Enter Confirmation Password
- Click `Continue` Button

----

Add test cases for `Client Select` page.

- Search Clients [Test Case]
  - Enter Client Name [Step[]]
  -  Should display only matching clients [Result]
- Select Client [Test Case]
  - Click client row [Step]
  - Should login as selected client [Result]

----

Add test cases for `Dashboard` page.

- Validate Components Loading [Test Case]
  - Position Pipeline [Step]
  - Market Movement [Step]
  - Loans Available for Sale [Step]
  - Latest Bid Request [Step]
  - Shock Profile [Step]
    - GL Tab
    - Position Tab
    - Data Tab
  - Month-To-Date Snapshot [Step]
    - GL Tab
    - Locks/Coverage Tab
    - Base Instrument Tab
    - Position Tab
  - Locks [Step]
    - Filter By Products
  - Loan Sales Summary [Step]
  - Loan Sales (Rolling 30 Days) [Step]
  - Recent Trades [Step]
  - Lock Volume [Step]

  ----

  Add `Dashboard` test cases:

- Position Pipeline Link:
  - Clicking should take user to `hedgeposition` page.
- Loans Available For Sale Link:
  - Clicking should take user to `request-bids` page.
- Latest Bid Request Link:
  - Clicking should take user to `commit-loans` page.
- Recent Trades Link:
  - Clicking should take user to `trademanagement` page.

  ----

  Add test case to `Position Recon Page`.

`Position Attribute Definitions modal` filter: Definitions should be filtered based on input.
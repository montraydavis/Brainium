# Page-Level Components

This documentation covers the essential page-level components of a financial trading interface, focusing on hedge selection, risk management, and trading assistance.

## Definitions Link
- **Identifier:** `definitionsLink`
- **Description:** A hyperlink that, when clicked, opens a modal window containing Hedge Selection Definitions. This feature is designed to provide users with quick access to critical explanations and terminologies related to hedge selection, enhancing their understanding and decision-making process.

## Refresh Risk Position Button
- **Identifier:** `refreshRiskPositionButton`
- **Description:** A button that refreshes the risk position data displayed on the page. This function is crucial for traders and risk managers who require the most current information to accurately assess risk and make informed decisions.

## Projections Button
- **Identifier:** `projectionsButton`
- **Description:** A button that opens a modal window to display projections. This modal provides users with forward-looking insights, allowing them to plan and strategize based on potential future scenarios. The projections can cover various aspects such as market movements, portfolio performance, and risk exposure.

## Trade Assistant Button
- **Identifier:** `tradeAssistamtButton`
- **Description:** A button that launches the trade assistant modal. This tool is designed to aid users in their trading decisions by providing them with valuable information, recommendations, or automated assistance based on the platform's algorithms and the user's trading preferences.

## Clear Activity Dropdown
- **Identifier:** `clearActitivityDropdown`
- **Description:** A dropdown menu that offers users options to clear different types of activities within the interface. This feature is essential for managing the workspace by removing outdated or unnecessary information.
  - **Options:**
    - **Clear Activity:** Removes general activity data from the view, helping users declutter the interface.
    - **Clear Trades:** Specifically targets and removes trade-related activities, allowing for a focused review of other data.
    - **Clear All Activity:** Provides a quick way to reset the activity log by clearing all types of activities, facilitating a fresh start or new analysis.

## Trade Blotter Footer
- **Identifier:** `tradeBlotterFooter`
- **Description:** A footer area that displays trade blotter data, offering a summary or detailed view of trading activities. This component is vital for users needing to keep track of trades, positions, and related metrics at a glance.
  - **Children:**
    - **Broker Dealer Usage Link:** A hyperlink that opens a modal detailing broker-dealer usage. This information is beneficial for understanding the involvement and performance of broker-dealers within the user's trading activities.

## Hedge Selection Grid
- **Identifier:** `hedgeSelectionGrid`
- **Description:** A grid that presents Hedge Selection data, structured to display various hedges and related metrics. This component is key for users managing hedge strategies, providing a comprehensive overview that supports effective decision-making.
  - **Children:**
    - **Hedge Selection Row:** Individual rows within the grid, each representing specific hedge selection data. These rows allow for detailed analysis of each hedge, including its performance, risk, and alignment with the user's objectives.


# Projections Modal
- **Description:** Displays projections data within a comprehensive modal, equipped with multiple tabs for detailed analysis of various projection types. Users can review impacts, adjust projection specifics, and understand potential future scenarios related to their trading strategies.

## Children Components

### Review Impact Button
- **Description:** Allows the user to review the impact of the projections on their current position. A critical tool for assessing potential future strategies.

### Cancel Button
- **Description:** Provides the user the option to cancel any changes or projections made during the session and close the modal.

### Close Button
- **Description:** Closes the Projections modal, useful for when the user has finished reviewing or adjusting projections.

### Projected Locks Tab
- **Description:** Dedicated to displaying and managing projected locks, this tab includes detailed controls for fine-tuning the projections.
  #### Projected Locks Toggle
  - **Description:** A toggle switch to include or exclude projected locks from the total projections amount.
  
  #### Projected Locks Amount Input
  - **Description:** Displays the total amount of projected locks. This field is not editable to ensure data integrity but provides a clear view of the calculated projections.
  - **Metadata:**
    - **Editable:** False
  
  #### Projected Locks Details Container
  - **Description:** Hosts detailed components related to projected locks, offering users the ability to fine-tune their projection criteria.
    ##### Projection Type Radio Group
    - **Description:** Allows the user to select the type of projection for the locks, whether it's a window-based projection or a manual projection.
    - **Options:**
      - **Projection Window**
        - **Description:** Projects locks based on a predefined window, considering current and projected volumes.
          ###### Todays Actual Volume Label
          - **Description:** Shows today's actual volume, providing a baseline for projections.
          
          ###### Todays Projected Volume Label
          - **Description:** Displays the projected volume for today, aiding in immediate strategic planning.
          
          ###### Projections Until Input
          - **Description:** Allows the user to set an end date for the projection window, defining the scope of the projection.
          
          ###### Projected Window Volume Label
          - **Description:** Shows the total volume projected within the selected window, offering insight into future activity levels.
      
      - **Manual Projection**
        - **Description:** Enables manual entry of projected locks, giving users the flexibility to apply their own projections outside of system-calculated suggestions.
          ###### Manual Projections Amount Input
          - **Description:** A field for inputting the amount of manual projections, offering users control over their projection data.
          
          ###### Projections Fallout Distribution Type Radio Group
          - **Description:** Allows users to specify the distribution type for the fallout from these projections.
            - **Options:**
              - **Benchmark Instrument**
                - **Description:** Uses a benchmark instrument for projecting the fallout distribution.
              
              - **Loans Expiring Before Date**
                - **Description:** Focuses projections on loans expiring before a specified date, helping target specific segments.
                  ####### Loans Expiring Before Date Input
                  - **Description:** A date input field for specifying the target date for loan expirations in projections.
    ##### Projected Locks Settings Link
    - **Description:** A link to access further settings related to projected locks, allowing for deeper customization.
    
    ##### Projected Locks Grid Container
    - **Description:** Displays a detailed grid of projected locks, including amounts and relevant details for each projection.

### Projected Fallout Tab
- **Description:** This tab is specifically designed for managing and reviewing projected fallout, giving users insights into potential future losses or expirations of loans. It allows for a detailed analysis of fallout, aiding in strategic planning and risk management.

#### Projected Fallout Toggle
- **Description:** A toggle control that allows users to include or exclude the projected fallout amount from the total projections calculation. This provides flexibility in forecasting by enabling users to adjust which projections are factored into their overall analysis.

#### Projected Fallout Amount Label
- **Description:** Displays the calculated amount of projected fallout. This label offers a quick snapshot of the potential future losses, making it easier for users to grasp the magnitude of projected fallout without delving into the details.

#### Projected Fallout Details Container
- **Description:** A container that encapsulates detailed components related to fallout projections. This section is crucial for users who need to drill down into specific aspects of their projected fallout, offering customizability and deeper insights.
  ##### Projection Type Radio Group
  - **Description:** Allows users to select the method by which the projected fallout is calculated. This choice significantly influences the projection outcomes, tailoring the fallout estimates to the user’s specific context.
    - **Options:**
      - **Loans Expiring Today**
        - **Description:** Limits the projected fallout to loans that are expiring today. This option focuses on the immediate risk of fallout, providing a narrow but detailed view of urgent exposures.
        
      - **Copy/Paste Loan IDs**
        - **Description:** Enables users to specify a list of loan IDs for which the fallout is to be projected. This method allows for highly targeted fallout projections, focusing on specific loans identified by the user.
          ###### Copy/Paste Loan IDs Input List
          - **Description:** A list of input fields where users can enter or paste the loan IDs they wish to include in their fallout projection. This feature offers precision in managing projections, allowing for tailored analysis based on selected loans.
        
      - **Manual Projection**
        - **Description:** Allows for a manual projection of fallout, giving users the utmost flexibility in defining their fallout estimates. This option is ideal for scenarios where the user has specific insight or data that the system cannot automatically account for.
          ###### Distribution Type Radio Group
          - **Description:** Enables users to choose how the manually projected fallout is distributed across the selected loans or categories.
            - **Options:**
              - **Benchmark Distribution**
                - **Description:** Distributes the projected fallout according to a predefined benchmark, ensuring that the fallout is allocated in a manner consistent with established patterns or expectations.
              
              - **Loans Expiring Before Date Input**
                - **Description:** Focuses the manual fallout projection on loans expiring before a specified date. This option helps in targeting projections towards loans at risk of expiring soon, aiding in proactive risk management.
                  ####### Loans Expiring Before Date Input
                  - **Description:** A field where users can specify the cutoff date for loans included in the fallout projection. This input is crucial for refining the projection to focus on loans with imminent risk of fallout.

#### Projected Fallout Grid Container
- **Description:** Displays a grid detailing the projected fallout, including individual loans or categories and their respective projected fallout amounts. This component is key for users who need a comprehensive breakdown of their fallout projections, offering visibility into where potential losses may occur.
  ##### Projected Fallout Expansion Link
  - **Description:** A link or button that allows users to expand or collapse rows within the fallout projection grid for a more detailed or condensed view.
  
  ##### Projected Fallout Summary Grid
  - **Description:** Provides a summary of the projected fallout, aggregating data for a quick overview. This grid simplifies the analysis by condensing detailed fallout projections into key figures and metrics.

This tab, with its detailed components and options, offers a robust tool for financial analysts and traders to anticipate and plan for potential loan expirations or defaults, integral to effective risk management strategies.

### Projected Loan Sales Tab
- **Description:** Focuses on the estimation and analysis of future loan sales, equipping users with tools to forecast and strategize around the sale of loans. This tab is particularly useful for financial institutions looking to manage their loan portfolio actively and anticipate cash flows from loan sales.

#### Projected Loan Sales Toggle
- **Description:** A toggle feature that allows users to decide whether to include the projected loan sales amount in the overall projections. This provides flexibility in the financial planning process by enabling users to easily adjust the scope of their projections based on their current focus.

#### Projected Loan Sales Amount Label
- **Description:** Displays the total amount of projected loan sales. This label offers a quick overview of the potential revenue from loan sales, aiding in liquidity management and financial forecasting.

#### Projected Loan Sales Details Container
- **Description:** A container for detailed components related to loan sales projections, offering depth and customization for users who need to fine-tune their sales forecasts.
  ##### Projection Type Radio Group
  - **Description:** Allows users to select the basis for their loan sales projections, tailoring the forecast to specific aspects of the loan portfolio or market conditions.
    - **Options:**
      - **Loans Available for Sale**
        - **Description:** Focuses projections on loans currently available for sale, helping users estimate potential sales based on the current portfolio.
        
      - **Offered Loans**
        - **Description:** Limits the projection to loans that have already been offered for sale, providing insight into the short-term sales outlook based on existing offers.
        
      - **Copy/Paste Loan IDs**
        - **Description:** Enables precise control over the projection by allowing users to specify which loans are considered in the sales forecast through a list of loan IDs. This method is particularly useful for targeting specific segments of the portfolio for analysis.
          ###### Copy/Paste Loan IDs Input List
          - **Description:** A list where users can input or paste the IDs of loans they wish to include in their sales projections. This feature offers granular control over the projection process, enabling detailed analysis and strategy formulation.

#### Projected Loan Sales Grid Container
- **Description:** Shows a detailed grid of projected loan sales, including information such as the amount, expected sale date, and potential buyer. This grid is crucial for users who require a comprehensive view of their sales forecast, allowing for informed decision-making and strategy development.
  ##### Projected Loan Sales Expansion Link
  - **Description:** Allows users to expand or collapse the details within the loan sales projection grid, providing flexibility in how the information is displayed.
  
  ##### Projected Loan Sales Selected Loans Label
  - **Description:** Indicates the number of loans selected for inclusion in the sales projections, offering users a quick reference to the scope of their current projection.
  
  ##### Projected Loan Sales Grid
  - **Description:** A comprehensive grid that displays detailed data for each loan included in the sales projections. This component is essential for users needing to analyze individual loan details to refine their sales strategies and expectations.

This tab, through its detailed components and flexible options, serves as an essential tool for financial analysts, portfolio managers, and traders. It aids in the strategic planning of loan sales, helping institutions to optimize their portfolio management and financial outcomes.

### Additional Projections Tab
- **Description:** Designed to accommodate projections that do not fall into the standard categories of locks, fallout, or loan sales. This tab allows users to include other types of projections, such as fees, penalties, or any other ancillary income or expenses, providing a more comprehensive financial outlook.

#### Additional Projections Toggle
- **Description:** A toggle switch enabling users to include or exclude additional projections from the total projections calculation. This feature allows for a customizable approach to financial forecasting, giving users the ability to tailor their projections to include all relevant financial streams.

#### Additional Projections Amount Label
- **Description:** Displays the total amount of additional projections, providing a quick overview of the financial impact of these ancillary projections. This label helps users understand the magnitude of additional projections relative to their overall financial strategy.

#### Additional Projections Summary Container
- **Description:** A container that encapsulates components related to the summary and details of additional projections. This area is crucial for users who need to manage various types of projections, offering a centralized location to view and analyze this data.
  ##### Additional Projections Summary Grid Expansion Link
  - **Description:** A link or button that allows users to expand or collapse the additional projections summary grid. This control provides flexibility in how information is displayed, enabling users to adjust the view according to their analysis needs.
  
  ##### Additional Projections Summary Grid
  - **Description:** Displays a grid summarizing the additional projections, including categories, amounts, and any relevant details. This grid is key for users needing a quick but comprehensive overview of all additional projections, facilitating informed decision-making and strategic planning.

The Additional Projections Tab is an essential component for users who require a holistic view of their financial projections. By accommodating a wide range of financial streams beyond the standard categories, this tab ensures that all potential income and expenses are considered in the financial planning process. This comprehensive approach aids in the creation of more accurate and actionable financial forecasts.

### Total Projections Tab
- **Description:** Provides a consolidated view of all projections, including locks, fallout, loan sales, and additional projections. This tab is instrumental for users who need a holistic overview of their projected financial landscape, enabling comprehensive analysis and strategic planning.

#### Total Projected Amount Label
- **Description:** Displays the aggregate amount of all projections that have been toggled to be included in the total projection amount. This label offers a quick summary of the total projected financial impact, assisting in overarching financial analysis and decision-making.

#### Total Projections Grid
- **Description:** A detailed grid that presents a breakdown of the total projections across all categories. This grid is crucial for users who require a detailed analysis of how each type of projection contributes to the overall financial picture, allowing for nuanced strategy adjustments and informed forecasting.

##### Features of the Total Projections Grid:
- **Granular Breakdown:** Each row provides details on the different types of projections, such as the projected locks, fallout, loan sales, and any additional projections. This granularity helps users pinpoint where adjustments may be needed in their strategies.
  
- **Aggregated Insights:** The grid aggregates insights from various projection types, offering a comprehensive view that supports strategic financial planning and risk management.
  
- **Customization Options:** Users can customize the view within the grid, filtering by projection type, amount, and other relevant criteria to focus on specific areas of interest or concern.
  
- **Interactive Elements:** The grid includes interactive elements such as expansion options for detailed analysis and hyperlinks to dive deeper into specific projections or underlying assumptions.

The Total Projections Tab serves as a pivotal tool for financial professionals, providing a macro-level view of projected outcomes based on current data and assumptions. This comprehensive perspective is essential for effective financial planning, risk assessment, and strategic decision-making, ensuring that all aspects of financial projections are considered and analyzed.



# Test Cases

## Hedge Selection Tool > Projections Modal > Include amount in `Total Projections Tab > Total Projections Amount` in Additional Projections Tab

### Description
Ensure that the amount specified in the `Total Projections Tab > Total Projections Amount` is included within the Additional Projections Tab for comprehensive projections overview.

### Steps
1. Navigate to the `Additional Projections Tab`.
2. Validate that the `Total Projections Tab` loads correctly.
3. Confirm that the `Total Projections Amount` correctly includes the projected amount.

### Expected Results
- The `Total Projections Amount` should accurately reflect the total projections within the Additional Projections Tab, ensuring users have a comprehensive view of their projections.

---

## Hedge Selection Tool > Validate Broker Dealer Usage Link opens modal

### Description
Check the Broker Dealer Usage link on the Hedge Selection Tool page to see if it correctly opens the Broker Dealer Usage modal.

### Steps
1. Click the `Broker Dealer Usage` link. This triggers the opening of the Broker Dealer Usage modal, offering users insight into broker-dealer usage statistics.

### Expected Results
- Clicking the `Broker Dealer Usage` link should open the `Broker Dealer Usage` modal, verifying that the link operates as expected and provides the intended information.

---

## Hedge Selection Tool > Validate Clear Activity Dropdown

### Description
Test the functionality of the Clear Activity dropdown within the Hedge Selection Tool page, focusing on its ability to clear selected activities.

### Steps
1. Select an option from the `Clear Activity` dropdown. This selects an activity for clearance from a list of available activities in the dropdown menu.

### Expected Results
- After selecting an activity from the `Clear Activity` dropdown, validate that the chosen activity is cleared. This outcome ensures that the dropdown is functioning as intended, allowing users to remove specific activities from their selection.

---

## Hedge Selection Tool > Validate Hedge Selection Row Expansion

### Description
Assess the expandability of the Hedge Selection Row within the Hedge Selection Grid on the Hedge Selection Tool page.

### Steps
1. Click the `Hedge Selection Row` in the `Hedge Selection Grid`. This action is expands the row to reveal more details about the hedge selection.

### Expected Results
- The `Hedge Selection Row` should expand upon being clicked, validateing that the row is interactive and capable of displaying additional details as designed.

---

## Hedge Selection Tool > Validate Projections Button opens modal

### Description
Validate the functionality of the Projections button on the Hedge Selection Tool page, ensuring it successfully opens the Projections modal.

### Steps
1. Click the `Projections` button. This open the Projections modal, allowing users to view projections related to their hedge selections.

### Expected Results
- Upon clicking the `Projections` button, the `Projections` modal should open, validating the button is properly linked to the modal and functioning as expected.

---

## Hedge Selection Tool > Validate Projections Modal

### Description
Validate the comprehensive functionality and availability of elements within the Projections Modal on the Hedge Selection Tool page.

### Steps
1. Click the `Projections` button to open the Projections modal.
2. Validate that the `Projections` modal opens successfully.
3. Ensure the `Review Impact` button is present and functional.
4. Check for the presence and functionality of the `Cancel` button.
5. Confirm that the `Close` button is available and works as expected.
6. Validate that the `Projected Locks` tab is accessible.
7. Ensure the `Projected Fallout` tab can be accessed and is functional.
8. Check that the `Projected Loan Sales` tab is present and works correctly.
9. Confirm the availability and functionality of the `Additional Projections` tab.
10. Ensure that the `Total Projections` tab loads and displays expected content.

---

## Hedge Selection Tool > Validate Trade Assistant Button opens modal

### Description
Ensure the Trade Assistant button on the Hedge Selection Tool page works correctly by opening the Trade Assistant modal.

### Steps
1. Click the `Trade Assistant` button. This opens the Trade Assistant Modal, which provides users with assistance in their trade selections.

### Expected Results
- The action of clicking the `Trade Assistant` button should result in the `Trade Assistant` modal opening, validateing the button's effectiveness and its link to the modal.

---

## Projections Modal > Projected Fallout Tab > Projected Fallout Summary Selected Loans Label for the selected projection type

### Description
Validate the Projections Summary Selected Loans Label in the Projections Modal displays the correct number of selected loans based on the selected projection type.

### Steps
1. Click the `Projections` button to access the Projections Modal.
2. Select the `Projected Fallout` tab.
3. Select an option in the Projection Type Radio Group.

### Expected Results
- The `Projections Summary Selected Loans Label` should display the number of selected loans based on the chosen projection type, ensuring accurate representation of loan selections.

---

## Projections Modal > Projected Loan Sales Tab > Projected Loan Sales Summary Selected Loans Label for the selected projection type

### Description
Validate the selected loans label is displayed for the selected projection type within the Projected Loan Sales Tab.

### Steps
1. Click the `Projections` button to enter the Projections Modal.
2. Navigate to the `Projected Loan Sales` tab.
3. Select an option in the Projection Type Radio Group to specify the projection type.

### Expected Results
- The `Projections Summary Selected Loans Label` should accurately display the number of selected loans based on the selected projection type, ensuring users are informed of their selections.

---

## Projections Modal > Projected Locks Tab > Grid Expand/Collapse Button

### Description
Validate the Projection Locks Summary Expansion Button toggles expanded / collapsed state of the Projection Locks Summary Grid.

### Steps
1. Click the `Projections` button to open the Projections Modal.
2. Select the `Projected Fallout` tab.
3. Click the `Projection Locks Summary Expansion Button` to toggle the expanded or collapsed state of the Projection Locks Summary Grid.

### Expected Results
- The Projection Locks Summary Grid should toggle between its expanded and collapsed states when the `Projection Locks Summary Expansion Button` is clicked, indicating it functions as designed.

---

## Projections Modal > Projected Locks Tab > Projected Locks Summary Selected Loans Label for the selected projection type

### Description
Validate the Projections Summary Selected Loans Label in the Projections Modal displays the correct number of selected loans based on the selected projection type.

### Steps
1. Click the `Projections` button to access the Projections Modal.
2. Navigate to the `Projected Locks` tab.
3. Select an option in the Projection Type Radio Group to specify the projection type.

### Expected Results
- The `Projections Summary Selected Loans Label` should accurately display the number of selected loans based on the selected projection type, ensuring users have clear visibility of their selections' impact.

---

## Projections Modal > Projected Locks Tab > Projection Type Radio Group > Projected Window

### Description
Validate that the Projection Type Radio Group within the Projections Modal accurately displays the `Projected Window` based on the user's selection.

### Steps
1. Click the `Projections` button and access the Projections modal.
2. Navigate to the `Projected Locks` tab.
3. Select the appropriate option from the `Projection Type` radio group to display the `Projected Window`.

### Expected Results
- Depending on the selection within the `Projection Type` radio group, validate that the `Projection Window` accurately displays either `Today's Actual Amount` and `Today's Expected Amount` for the `Full Amount` option or the detailed `Projected Window` information for the `Projected Window` option.

---

## Projections Modal > Validate Additional Projections Tab Exists

### Description
Ensure the Additional Projections Tab is present and functions correctly within the Projections Modal.

### Steps
1. Click the `Projections` button to open the modal.
2. Select the `Additional Projections` tab.

### Expected Results
- The `Additional Projections` tab should load successfully, providing users with additional projections information.

---

## Projections Modal > Validate Projected Loan Sales Tab Exists

### Description
Validate the existence and functionality of the Projected Loan Sales Tab within the Projections Modal.

### Steps
1. Click the `Projections` button to access the Projections modal.
2. Navigate to the `Projected Loan Sales` tab.

### Expected Results
- Validate that the `Projected Loan Sales` tab loads correctly, ensuring users can access detailed projections related to loan sales.

---

## Projections Modal > Validate Projections Summary Grid in Projected Locks Tab

### Description
Ensure the Projections Summary Grid is displayed within the Projected Locks Tab of the Projections Modal, offering users detailed projections data.

### Steps
1. Click the `Projections` button to open the modal.
2. Select the `Projected Locks` tab.

### Expected Results
- Validate that the `Projections Summary Grid` is displayed, ensuring users can access detailed and organized projections information.

---

## Validate Projections Modal > Additional Projections Tab > Additional Projections Summary Grid

### Description
Validate the display of the Additional Projections Summary Grid within the Projections Modal, under the Additional Projections Tab.

### Steps
1. Click the `Projections` button to access the Projections Modal.
2. Select the `Additional Projections` tab.

### Expected Results
- The `Additional Projections Summary Grid` should be prominently displayed, providing users with a detailed view of additional projections information.

---
---

## Validate Projections Modal > Additional Projections Tab > Additional Projections Summary Grid Expand/Collapse Button

### Description
This test case verifies that the Additional Projections Expansion Button correctly toggles the expanded or collapsed state of the Additional Projections Summary Grid within the Projections Modal.

### Steps
1. Click the `Projections` button. This navigates to the Projections Modal.
2. Select the `Additional Projections` tab. This displays the Additional Projections section.
3. Click the `Additional Projections Expansion Button`. This triggers the toggle mechanism for expanding or collapsing the summary grid.

### Expected Results
- The Additional Projections Summary Grid should toggle between expanded and collapsed states each time the `Additional Projections Expansion Button` is clicked. This behavior indicates the button is functioning as intended, providing users with control over the display of additional projections information.

---

## Validate Projections Modal > Additional Projections Tab > Components Displayed

### Description
Ensure all key components within the Additional Projections Tab of the Projections Modal are visible and correctly displayed.

### Steps
1. Click the `Projections` button to access the Projections Modal.
2. Select the `Additional Projections` tab.

### Expected Results
- The `Additional Projections` toggle should be visible, allowing users to enable or disable additional projections.
- The `Additional Projections Amount Label` should display the total amount related to additional projections, offering quantitative insight.
- The `Additional Projections Summary Grid` should be visible, presenting detailed information on additional projections.

---

## Validate Projections Modal > Additional Projections Tab > Grid Expand/Collapse Button

### Description
Test the functionality of the Additional Projections Expansion Button in toggling the expanded or collapsed state of the Additional Projections Summary Grid.

### Steps
1. Open the Projections Modal by clicking the `Projections` button.
2. Go to the `Additional Projections` tab.
3. Click the `Additional Projections Expansion Button`.

### Expected Results
- The Additional Projections Summary Grid should alternate between expanded and collapsed states with each click of the `Additional Projections Expansion Button`, validateing the control's effectiveness in managing the grid's display.

---

## Validate Projections Modal > Projected Fallout Tab > Components Displayed

### Description
Validate the Projections Lock toggle in the Projections Modal is displayed along with other key components within the `Projected Fallout` tab.

### Steps
1. Click the `Projections` button to open the Projections Modal.
2. Select the `Projected Fallout` tab to view its contents.

### Expected Results
- The Projections Lock toggle should be visible, indicating its availability for user interaction.
- The Projections Locks Amount should be displayed, providing a quantitative overview of locks.
- The Projection Type Radio Group should be accessible, allowing users to select different projection types.
- The Projected Fallout Summary Grid should be visible, offering detailed insights into projected fallout.

---

## Validate Projections Modal > Projected Fallout Tab > Grid Expand/Collapse Button

### Description
Validate the Projected Fallout Summary Expansion Button toggles expanded / collapsed state of the Projection Fallout Summary Grid.

### Steps
1. Click the `Projections` button to access the Projections Modal.
2. Navigate to the `Projected Fallout` tab.
3. Click the `Projected Fallout Summary Expansion Button` to toggle the grid's state.

### Expected Results
- The Projected Fallout Summary Grid should alternate between expanded and collapsed states upon each click of the `Projected Fallout Summary Expansion Button`, validateing the button's functionality.



## Validate Projections Modal > Projected Fallout Tab > Grid Expand/Collapse Button

### Description
Validate the functionality of the Projected Loan Sales Expansion Button in toggling the expanded or collapsed state of the Projected Fallout Summary Grid.

### Steps
1. Open the Projections Modal by clicking the `Projections` button.
2. Navigate to the `Projected Fallout` tab.
3. Click the `Projected Fallout Expansion Button` to toggle the grid's display state.

### Expected Results
- The Projected Fallout Summary Grid should alternate between expanded and collapsed states upon clicking the `Projected Fallout Expansion Button`, indicating control over the grid's display.

---

## Validate Projections Modal > Projected Fallout Tab > Projected Fallout Summary Grid

### Description
Validate the visibility of the `Projected Fallout Summary Grid` within the Projections Modal, specifically in the `Projected Fallout` tab.

### Steps
1. Click the `Projections` button to enter the Projections Modal.
2. Select the `Projected Fallout` tab to view its contents.

### Expected Results
- The `Projected Fallout Summary Grid` should be visible in the `Projected Fallout` tab, offering users detailed insights into the projected fallout data.

---

## Validate Projections Modal > Projected Fallout Tab > Projected Fallout Type Radio Group > Displays Expected Loan Expiration for Today Selection

### Description
Ensure `Expected Loan Expiration for Today` is displayed when `Today` is selected in the Projection Type Radio Group within the `Projected Fallout` tab.

### Steps
1. Click the `Projections` button to open the Projections Modal.
2. Select the `Projected Fallout` tab.
3. Choose `Loans Expiring Today` in the `Projection Type` radio group to specify the projection.

### Expected Results
- The `Projection Window` should accurately display `Loans Expiring Today`, validateing that the Projection Type Radio Group correctly influences the content displayed to the user based on their selection.

---

## Validate Projections Modal > Projected Fallout Tab > Projected Fallout Type Radio Group > Displays Option for Copy/Paste Loan IDs

### Description
Validate the option to copy/paste loan IDs is displayed when selected in the Projection Type Radio Group within the `Projected Fallout` tab.

### Steps
1. Click the `Projections` button to access the Projections Modal.
2. Select the `Projected Fallout` tab.
3. Choose `Copy/Paste Loan IDs` in the `Projection Type` radio group.

### Expected Results
- An empty list for loan IDs should be available for copy/paste actions in the `Projection Window`, enabling users to manually input loan IDs for projections.

---

## Validate Projections Modal > Projected Fallout Tab > Projected Fallout Type Radio Group > Ensures Amount Displayed for Manual Selection

### Description
Ensure `Manual Projections Amount` is displayed when `Manual` is selected in the Projection Type Radio Group, alongside the `Distribution Type` radio group.

### Steps
1. Click the `Projections` button to open the Projections Modal.
2. Navigate to the `Projected Fallout` tab.
3. Select `Manual` in the `Projection Type` radio group.

### Expected Results
- `Manual Projections Amount` should be visible in the `Projected Fallout` tab, indicating the total amount for manual projections.
- The `Distribution Type` radio group should also be visible, allowing users to specify the distribution type for their manual projections.

---

## Validate Projections Modal > Projected Fallout Tab > Projected Fallout Type Radio Group > Ensures Distribution Type Radio Group Displayed

### Description
Validate that the `Distribution Type` radio group is prominently displayed when `Manual` is chosen in the Projection Type Radio Group within the `Projected Fallout` tab.

### Steps
1. Access the Projections Modal by clicking the `Projections` button.
2. Go to the `Projected Fallout` tab.
3. Select `Manual` from the Projection Type radio group.

### Expected Results
- The `Distribution Type` radio group should be clearly visible in the `Projected Fallout` tab, facilitating user selection for distribution type in manual projections.

---

## Validate Projections Modal > Projected Fallout Tab > Projected Loan Sales Type Radio Group > Displays Option for Copy/Paste Loan IDs

### Description
Ensure the functionality for copying/pasting loan IDs is accessible when selected from the Projection Type Radio Group within the Projected Fallout tab.

### Steps
1. Click the `Projections` button to access the Projections Modal.
2. Select the `Projected Fallout` tab.
3. Choose `Copy/Paste Loan IDs` in the `Projection Type` radio group.

### Expected Results
- An interface or area for copying and pasting loan IDs should be available, enabling users to manually input loan IDs for specific projections.

---

## Validate Projections Modal > Projected Loan Sales Tab > Grid Expand/Collapse Button

### Description
Test the functionality of the Projected Loan Sales Expansion Button in toggling the expanded or collapsed state of the Projected Loan Sales Summary Grid.

### Steps
1. Click the `Projections` button to enter the Projections Modal.
2. Go to the `Projected Loan Sales` tab.
3. Click the `Projected Loan Sales Expansion Button`.

### Expected Results
- The Projected Loan Sales Summary Grid should toggle between its expanded and collapsed states upon each click, validateing the button's effectiveness in controlling the grid's view.



## Validate Projections Modal > Projected Loan Sales Tab > Grid Expand/Collapse Button

### Description
Validate the Projected Loan Sales Expansion Button toggles expanded / collapsed state of the Projected Loan Sales Summary Grid.

### Steps
1. Click the `Projections` button to open the Projections Modal.
2. Select the `Projected Loan Sales` tab.
3. Click the `Projected Loan Sales Expansion Button`.

### Expected Results
- The Projected Loan Sales Summary Grid should toggle between expanded and collapsed states upon clicking the `Projected Loan Sales Expansion Button`, demonstrating the button's functional interaction with the grid view.

---

## Validate Projections Modal > Projected Loan Sales Tab > Projected Loan Sales Summary Grid

### Description
Confirm the visibility of the Projected Loan Sales Summary Grid within the Projections Modal, specifically under the Projected Loan Sales tab.

### Steps
1. Click the `Projections` button to access the Projections Modal.
2. Select the `Projected Loan Sales` tab.

### Expected Results
- The `Projected Loan Sales Summary Grid` should be clearly visible, providing a detailed overview of projected loan sales information.

---

## Validate Projections Modal > Projected Loan Sales Tab Components Displayed

### Description
Ensure that key components within the Projected Loan Sales Tab of the Projections Modal are displayed correctly.

### Steps
1. Click the `Projections` button to open the Projections Modal.
2. Navigate to the `Projected Loan Sales` tab.

### Expected Results
- The `Projected Loan Sales Toggle` should be visible, indicating the user's ability to toggle the loan sales projection feature.
- The `Projected Loan Sales Amount Label` should display the total amount of projected loan sales, providing crucial financial information.
- The `Projected Loan Sales Summary Grid` should be visible, offering detailed insights into each projected loan sale.
- The `Projected Loan Sales Radio Group` should be available, allowing users to select among different projection types or criteria.

---

## Validate Projections Modal > Total Projections Tab > Grid Expand/Collapse Button

### Description
This test verifies that the Total Projections Expansion Button successfully toggles the expanded and collapsed states of the Total Projections Summary Grid within the Projections Modal.

### Steps
1. Click the `Projections` button to enter the Projections Modal.
2. Select the `Total Projections` tab to view the section dedicated to total projections.
3. Click the `Total Projections Expansion Button` to initiate the toggle functionality for the summary grid's display.

### Expected Results
- Each click on the `Total Projections Expansion Button` should alternate the Total Projections Summary Grid between its expanded and collapsed states. This test validates that the expansion button works as intended, allowing users to adjust the display according to their preference.

---

## Validate Projections Modal > Total Projections Tab > Total Projections Components Display

### Description
This test case aims to ensure that both the `Total Projections Amount Label` and `Total Projections Summary Grid` are properly displayed within the Total Projections tab of the Projections Modal.

### Steps
1. Click the `Projections` button to access the Projections Modal.
2. Select the `Total Projections` tab to view the Total Projections information.

### Expected Results
- The `Total Projections Amount Label` should be clearly visible within the `Total Projections` tab, indicating the total projections amount to the user.
- The `Total Projections Summary Grid` should also be visible, providing a detailed breakdown of the total projections.

---

## Validate Projections Modal > Total Projections Tab > Total Projections Summary Grid

### Description
This test case validates the visibility and proper display of the Total Projections Summary Grid within the Projections Modal, specifically in the Total Projections tab.

### Steps
1. Click the `Projections` button to open the Projections Modal.
2. Navigate to the `Total Projections` tab to focus on total projections details.

### Expected Results
- The `Total Projections Summary Grid` is expected to be visible in the `Total Projections` tab, ensuring users can view a comprehensive summary of total projections.
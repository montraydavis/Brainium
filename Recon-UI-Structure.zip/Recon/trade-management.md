# Trade Management Page Components

This document provides a comprehensive overview of the components on the Trade Management page, highlighting their functionalities essential for managing and monitoring trades.

## Components

### hpTradeManagement
- **Identifier:** `hpTradeManagement`
- **Description:** Acts as the main container for Trade Management tabs, facilitating the organization and display of different trade-related grids.

#### Open Trades Tab
- **Identifier:** `hpTradeManagementOpenTradesTab`
- **Description:** Displays a grid of open trades, allowing users to monitor active trading positions.
  - **Open Trades Grid**
    - **Identifier:** `hpTradeManagementOpenTradesTabOpenTradesGrid`
    - **Description:** Showcases open trades, serving as an essential tool for managing and tracking current trade activities.
      - **Open Trades Grid Row Trade ID Link**
        - **Identifier:** `hpTradeManagementOpenTradesTabOpenTradesGridOpenTradesGridRowTradeIdLink`
        - **Description:** Link to open Trade Details Viewer page with the selected trade ID, providing direct access to detailed trade information.

#### All Trades Tab
- **Identifier:** `hpTradeManagementAllTradesTab`
- **Description:** Tab that displays a grid of all trades, offering a complete overview of trade history.
  - **All Trades Grid**
    - **Identifier:** `hpTradeManagementAllTradesTabAllTradesGrid`
    - **Description:** Lists all trades, enabling users to analyze trade history and details comprehensively.
      - **All Trades Grid Row Trade ID Link**
        - **Identifier:** `hpTradeManagementAllTradesTabAllTradesGridAllTradesGridRowTradeIdLink`
        - **Description:** Link to open Trade Details Viewer page with the selected trade ID, facilitating detailed trade analysis.

#### Unsettled Transactions Tab
- **Identifier:** `hpTradeManagementUnsettledTransactionsTab`
- **Description:** Displays a grid of unsettled transactions, highlighting trades that are pending settlement.
  - **Unsettled Transactions Grid**
    - **Identifier:** `hpTradeManagementUnsettledTransactionsTabUnsettledTransactionsGrid`
    - **Description:** Focuses on unsettled transactions, crucial for tracking trades awaiting completion.
      - **Unsettled Transactions Grid Row Trade ID Link**
        - **Identifier:** `hpTradeManagementUnsettledTransactionsTabUnsettledTransactionsGridUnsettledTransactionsGridRowTradeIdLink`
        - **Description:** Link to open Trade Details Viewer page with the selected trade ID, aiding in unsettled trade management.

#### All Transactions Tab
- **Identifier:** `hpTradeManagementAllTransactionsTab`
- **Description:** Tab displaying a grid of all transactions, providing a full account of trading activities.
  - **All Transactions Grid**
    - **Identifier:** `hpTradeManagementAllTransactionsTabAllTransactionsGrid`
    - **Description:** Shows all transactions, essential for a comprehensive overview and tracking of all trade-related activities.
      - **All Transactions Grid Row Trade ID Link**
        - **Identifier:** `hpTradeManagementAllTransactionsTabAllTransactionsGridAllTransactionsGridRowTradeIdLink`
        - **Description:** Link to open Trade Details Viewer page with the selected trade ID, ensuring thorough analysis of transactions.

#### Associations Tab
- **Identifier:** `hpTradeManagementAssociationsTab`
- **Description:** Displays a grid of associations, showcasing links between trades and transactions.
  - **Associations Grid**
    - **Identifier:** `hpTradeManagementAssociationsTabAssociationsGrid`
    - **Description:** Reveals associations between trades, crucial for understanding the interconnectedness of trading activities.
      - **Associations Grid Row Trade ID Link**
        - **Identifier:** `hpTradeManagementAssociationsTabAssociationsGridAssociationsGridRowTradeIdLink`
        - **Description:** Link to open Trade Details Viewer page with the selected trade ID, valuable for detailed association analysis.

# Test Cases for Trade Management Page

## Validate Grid Components
- **Objective:** Confirm all essential grid components on the Trade Management page are functioning and correctly displayed.
- **Steps:**
  1. Navigate to the `Trade Management` page.
- **Expected Results:**
  - Validate the `Open Trades` tab loads the `Open Trades` grid.
  - Validate the `All Trades` tab loads the `All Trades` grid.
  - Validate the `Unsettled Transactions` tab loads the `Unsettled Transactions` grid.
  - Validate the `All Transactions` tab loads the `All Transactions` grid.
  - Validate the `Associations` tab loads the `Associations` grid.

## Validate `Trade ID Link` Opens Trade Details Viewer in the `Open Trades` Tab
- **Objective:** Ensure that the Trade ID Link in the Open Trades grid opens the Trade Details Viewer page.
- **Steps:**
  1. Navigate to the `Trade Management` page.
  2. Select the `Open Trades` tab.
  3. Click on the `Trade ID Link` in the `Open Trades` grid.
- **Expected Results:**
  - Validate that the user is navigated to the `Trade Details Viewer`.

## Validate `Trade ID Link` Opens Trade Details Viewer in the `All Trades` Tab
- **Objective:** Verify that the Trade ID Link in the All Trades grid navigates to the Trade Details Viewer page.
- **Steps:**
  1. Navigate to the `Trade Management` page.
  2. Select the `All Trades` tab.
  3. Click on the `Trade ID Link` in the `All Trades` grid.
- **Expected Results:**
  - Validate that the user is navigated to the `Trade Details Viewer`.

## Validate `Trade ID Link` Opens Trade Details Viewer in the `Unsettled Transactions` Tab
- **Objective:** Check that the Trade ID Link in the Unsettled Transactions grid opens the Trade Details Viewer page.
- **Steps:**
  1. Navigate to the `Trade Management` page.
  2. Select the `Unsettled Transactions` tab.
  3. Click on the `Trade ID Link` in the `Unsettled Transactions` grid.
- **Expected Results:**
  - Validate that the user is navigated to the `Trade Details Viewer`.

## Validate `Trade ID Link` Opens Trade Details Viewer in the `All Transactions` Tab
- **Objective:** Confirm that clicking the Trade ID Link in the All Transactions grid opens the Trade Details Viewer page.
- **Steps:**
  1. Navigate to the `Trade Management` page.
  2. Select the `All Transactions` tab.
  3. Click on the `Trade ID Link` in the `All Transactions` grid.
- **Expected Results:**
  - Validate that the user is navigated to the `Trade Details Viewer`.

## Validate `Trade ID Link` Opens Trade Details Viewer in the `Associations` Tab
- **Objective:** Ensure the Trade ID Link in the Associations grid leads to the Trade Details Viewer page.
- **Steps:**
  1. Navigate to the `Trade Management` page.
  2. Select the `Associations` tab.
  3. Click on the `Trade ID Link` in the `Associations` grid.
- **Expected Results:**
  - Validate that the user is navigated to the `Trade Details Viewer`.

## Validate Grid Selection
- **Objective:** Verify the functionality of grid selection across all tabs on the Trade Management page.
- **Steps:**
  1. Navigate to the `Trade Management` page.
  2. Select a row in the `Open Trades` grid.
  3. Drag and select multiple rows in the `Open Trades` grid.
  4. Repeat steps 2 and 3 for the `All Trades`, `Unsettled Transactions`, `All Transactions`, and `Associations` grids.
- **Expected Results:**
  - Validate the selected row(s) are highlighted in the `Open Trades` grid.
  - Validate the selected row(s) are highlighted in the `All Trades` grid.
  - Validate the selected row(s) are highlighted in the `Unsettled Transactions` grid.
  - Validate the selected row(s) are highlighted in the `All Transactions` grid.
  - Validate the selected row(s) are highlighted in the `Associations` grid.
